<div class="sub-hero">
    <img class="floating-x" src="./assets/sub-hero/half-x.png" alt="">
    <h2 class="section-heading">WE DELIVER</h2>
    <p>Unconventional solutions and bold communication. We do it from the heart.</p>
</div>