<div class="nav-menu">
    <div class="left">
        <a href="">
            <img class="logo-header" src="./assets/hero/logo.png" alt="">
        </a>
    </div>
    <div class="right">
        <button class="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <ul>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CASE STUDIES</a></li>
            <li><a href="#" class="cta-btn-nav">CONTACT US</a></li>
        </ul>
    </div>
    <div class="side-menu">
        <ul>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="#">SERVICES</a></li>
            <li><a href="#">CASE STUDIES</a></li>
            <li><a href="#" class="cta-btn-nav">CONTACT US</a></li>
        </ul>
    </div>
</div>